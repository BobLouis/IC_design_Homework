1. Name the image to transfrom "image.jpg"
2. install library "pip3 install pillow"
3. execute "python3 main.py"
4. you will get two files "img.dat" and "golden.dat"